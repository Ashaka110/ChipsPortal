



**Disclaimer**
Chip's Challenge belongs to Alpha Omega.
Portal belongs to Valve.
I claim rights to neither of these games.
 